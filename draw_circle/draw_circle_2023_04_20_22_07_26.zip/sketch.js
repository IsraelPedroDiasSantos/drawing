function setup(){
  createCanvas(1200, 400);background('white');
}

function draw(){
stroke('black')  
fill('black');


if(mouseIsPressed) {
ellipse(mouseX,mouseY, 5, 5);  

 }
 } 